﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraphTheory
{
    class Graph
    {
        //список смежности
        private Dictionary<string, Dictionary<string, int>> graph;

        private bool oriented = true; //ориентированный или неориент

        private bool weighed = true; //взвешенный/невзвешенный

        //свойство ориентированности
        public bool Oriented
        {
            get
            {
                return oriented;
            }
            set
            {
                oriented = value;
            }
        }

        //свойство взвешенности
        public bool Weighed
        {
            get
            {
                return weighed;
            }
            set
            {
                weighed = value;
            }
        }

        //получить весь граф
        public Dictionary<string, Dictionary<string, int>> DictGraph
        {
            get
            {
                return graph;
            }
        }

        //конструктор по умолчанию
        public Graph()
        {
            graph = new Dictionary<string, Dictionary<string, int>>();
        }


        //конструктор копирования
        public Graph(Graph graph)
        {
            oriented = graph.Oriented;
            weighed = graph.Weighed;
            this.graph = new Dictionary<string, Dictionary<string, int>>(); //указатель на граф
            foreach (var item in graph.DictGraph)
            {
                string nameNode = "";
                nameNode += item.Key; //заносим главную вершину в строке
                Dictionary<string, int> vertex = new Dictionary<string, int>();
                //цикл по вершинам, смежных с главной
                foreach (var items in item.Value)
                {
                    vertex.Add(items.Key, items.Value); //добавляем по одной вершине, смежной с главной
                }
                this.graph.Add(nameNode, vertex); //добавили всю строку
            }
        }

        //конструктор добавления из файла
        public Graph(string filePath)
        {
            graph = new Dictionary<string, Dictionary<string, int>>();
            using (StreamReader file = new StreamReader(@filePath))
            {
                string[] orAndWei = file.ReadLine().Split();

                if (orAndWei[0] == "1")
                    oriented = true;
                else
                    oriented = false;

                if (orAndWei[1] == "1")
                    weighed = true;
                else
                    weighed = false;

                string tempStr;
                string[] nodeStr; //каждый узел
                string[] nodesStr; // вся строка 
                while ((tempStr = file.ReadLine()) != null)
                {
                    nodesStr = tempStr.Split();
                    Dictionary<string, int> tempNextNodes = new Dictionary<string, int>();
                    for (int i = 1; i < nodesStr.Length; i++)
                    {
                        nodeStr = nodesStr[i].Split(':');
                        tempNextNodes.Add(nodeStr[0], Convert.ToInt32(nodeStr[1]));
                    }
                    graph.Add(nodesStr[0], tempNextNodes); //вершина+узлы построчно
                }
            }
        }


        //добавление вершины
        public bool AddVertex(string nameNode)
        {
            Dictionary<string, int> dict = new Dictionary<string, int>();
            if (graph.ContainsKey(nameNode))//есть ли такая вершина в графе?
            {
                return false;
            }
            {
                graph.Add(nameNode, dict);
                return true;
            }
        }

        //удаление вершины
        public bool DeleteVertex(string nameNode)
        {
            bool deleted = graph.Remove(nameNode);
            foreach (var keyValue in graph)
            {
                graph[keyValue.Key].Remove(nameNode); //удаляем вершину по ключу
            }
            if (deleted)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //добавление ребра
        public bool AddEdge(string fromNode, string toNode, int weight = 0)
        {
            if (oriented)
            {
                if (graph[fromNode].ContainsKey(toNode) == false && graph[fromNode].ContainsKey(toNode) == false) //если нет таких рёбер
                {
                    graph[fromNode].Add(toNode, weight);
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                if (graph.ContainsKey(fromNode) && graph.ContainsKey(toNode))
                {
                    if (graph[fromNode].ContainsKey(toNode) == false && graph[fromNode].ContainsKey(toNode) == false)//если ещё граф не содержит введёные значения(т.е рёбра)
                    {
                        graph[fromNode].Add(toNode, weight);
                        graph[toNode].Add(fromNode, weight);
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
        }

        //удаление ребра
        public bool DeleteEdge(string fromNode, string toNode)
        {
            bool deletedEdge = false;
            if (String.IsNullOrEmpty(fromNode) || String.IsNullOrEmpty(toNode))//если оно уже не удалено
            {
                return false;
            }
            if (oriented)
            {
                foreach (var keyValue in graph)
                {
                    if (keyValue.Key.Equals(fromNode) && keyValue.Value.ContainsKey(toNode))//если есть данные значения
                    {
                        deletedEdge = true;
                        graph[keyValue.Key].Remove(toNode);
                    }
                }
            }
            else
            {
                foreach (var keyValue in graph)
                {
                    if (keyValue.Key.Equals(fromNode) && keyValue.Value.ContainsKey(toNode) || keyValue.Key.Equals(toNode) && keyValue.Value.ContainsKey(fromNode))
                    {
                        deletedEdge = true;
                        graph[keyValue.Key].Remove(toNode);
                        graph[keyValue.Key].Remove(fromNode);
                    }
                }
            }
            return deletedEdge;
        }


        //все вершины графа
        public string[] GetNodes()
        {
            string[] node = new string[graph.Count];
            int i = 0;
            foreach (var item in graph)
            {
                node[i] = item.Key;
                i++;
            }
            return node;
        }


        //вывод графа в консоль
        public void ShowLstVertex()
        {
            foreach (var keyValue in graph)
            {
                Console.Write(keyValue.Key + "->");
                foreach (var keyValue2 in keyValue.Value) //цикл по весам
                {
                    if (weighed) //если взвеш, то добавляем в выод ещё и вес
                    {
                        Console.Write(keyValue2.Key + ":" + keyValue2.Value + " ");
                    }
                    else
                    {
                        Console.Write(keyValue2.Key + " ");
                    }
                }
                Console.WriteLine();
            }
            Console.WriteLine();
        }

        //вывод в файл
        public void OutPutInFile(string str)
        {
            string oneNode;
            using (StreamWriter FileOut = new StreamWriter(str, false))
            {
                foreach (var keyValue in graph)
                {
                    oneNode = keyValue.Key + " ";
                    foreach (var keyValue2 in keyValue.Value)
                    {
                        oneNode += (keyValue2.Key + ":" + keyValue2.Value + " ");
                    }
                    FileOut.WriteLine(oneNode);
                }
            }
        }
    }
}