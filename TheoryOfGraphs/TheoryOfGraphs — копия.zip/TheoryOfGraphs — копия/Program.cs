﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GraphTheory
{
    class Program
    {
        static void Main(string[] args)
        {
        start:
            int val = 1;
            Console.Write("Нажмите 1 - создать пустой граф; 2 - считать с файла: ");
            Int32.TryParse(Console.ReadLine(), out val);
            Graph graph = new Graph();
            if (val == 1)
            {
                graph = new Graph();
                Console.Write("Граф будет ориентированным?(Да/Нет)");
                string str = Console.ReadLine();
                if (str == "Да")
                {
                    graph.Oriented = true;
                }
                else if (str == "Нет")
                {
                    graph.Oriented = false;
                }
                else
                {
                    Console.WriteLine("Неверно введены данные. Попробуйте ещё раз.");
                    goto start;
                }
                Console.Write("Граф будет взвешенным? ");
                str = Console.ReadLine();
                if (str == "Да")
                {
                    graph.Weighed = true;
                }
                else if (str == "Нет")
                {
                    graph.Weighed = false;
                }
                else
                {
                    Console.WriteLine("Неверно введены данные. Попробуйте ещё раз.");
                    goto start;
                }
            }
            else if (val == 2)
            {
                Console.WriteLine("Выберите файл: ");
                Console.WriteLine("1. Ориентированный взвешенный ");
                Console.WriteLine("2. Ориентированный невзвешенный ");
                Console.WriteLine("3. Неориентированный взвешенный ");
                Console.WriteLine("4. Неориетированный невзвешенный ");
                Console.Write("Введите число: ");
                string filePath = Console.ReadLine();
                if (filePath == "1")
                    graph = new Graph(@"C:\Users\Alina\source\repos\TheoryOfGraphs\TheoryOfGraphs\OriWeiGraph.txt");
                else if (filePath == "2")
                    graph = new Graph(@"C:\Users\Alina\source\repos\TheoryOfGraphs\TheoryOfGraphs\OriNoWeiGraph.txt");

                else if (filePath == "3")
                    graph = new Graph(@"C:\Users\Alina\source\repos\TheoryOfGraphs\TheoryOfGraphs\NoOriWei.txt");
                else if (filePath == "4")
                    graph = new Graph(@"C:\Users\Alina\source\repos\TheoryOfGraphs\TheoryOfGraphs\NoOriNoWei.txt");
                else
                {
                    Console.WriteLine("Нет такого числа");
                    return;
                }
            }
            while (val != 0)
            {
                Console.WriteLine("Меню для работы с графом:");
                Console.WriteLine("1.Добавить вершину");
                Console.WriteLine("2.Удалить вершину");
                Console.WriteLine("3.Добавить ребро");
                Console.WriteLine("4.Удалить ребро");
                Console.WriteLine("5.Просмотреть граф в консоли");
                Console.WriteLine("6.Загрузить в файл");
                Console.WriteLine("0.Выйти из программы");
                Console.Write("Введите число:");
                Int32.TryParse(Console.ReadLine(), out val);
                string str;
                string[] strArr;
                switch (val)
                {
                    case 1:
                        Console.WriteLine();
                        Console.Write("Введите название вершнины, которую нужно добавить: ");
                        str = Console.ReadLine();
                        if (graph.AddVertex(str))
                        {
                            Console.WriteLine("Вершина добавлена");
                        }
                        else
                        {
                            Console.WriteLine("Такая вершина уже есть. Добавлять можно только новые.");
                        }
                        Console.WriteLine();

                        break;
                    case 2:
                        Console.WriteLine();
                        Console.Write("Введите название вершины, которую нужно удалить: ");
                        str = Console.ReadLine();
                        if (graph.DeleteVertex(str))
                        {
                            Console.WriteLine("Вершина удалена.");
                        }
                        else
                        {
                            Console.WriteLine("Вершина не удалена. Проверьте данные.");
                        }
                        Console.WriteLine();
                        break;
                    case 3:
                        Console.WriteLine();
                        if (graph.Weighed)
                        {
                            Console.Write("Введите ('из', 'куда', 'вес') для добавления ребра: ");
                            strArr = Console.ReadLine().Split();
                            string[] vertex = graph.GetNodes();//для проверки наличия вершин графа
                            if (strArr.Length == 3 && int.TryParse(strArr[2], out _) && vertex.Contains(strArr[0]) && vertex.Contains(strArr[1]))
                            {
                                if (graph.AddEdge(strArr[0], strArr[1], Convert.ToInt32(strArr[2])))
                                {
                                    Console.WriteLine("Ребро добавлено.");
                                }
                                else
                                {
                                    Console.WriteLine("Нет такой вершины или уже есть такое ребро. Добавление ребра не выполнено.");
                                }
                            }
                            else
                            {
                                Console.WriteLine("Введены неверно данные.");
                            }
                        }
                        else
                        {
                            Console.Write("Введите ('из', 'куда') для добавления ребра: ");
                            strArr = Console.ReadLine().Split();
                            string[] vertex = graph.GetNodes(); //проверяем наличие вершины в графе
                            if (strArr.Length == 2 && vertex.Contains(strArr[0]) && vertex.Contains(strArr[1]))
                            {
                                if (graph.AddEdge(strArr[0], strArr[1]))
                                {
                                    Console.WriteLine("Ребро добавлено.");
                                }
                                else
                                {
                                    Console.WriteLine("Нет такой вершины или уже есть такое ребро. Добавление ребра не выполнено.");
                                }
                            }
                            else
                            {
                                Console.WriteLine("Введены неверно данные.");
                            }
                        }
                        Console.WriteLine();
                        break;
                    case 4:
                        Console.WriteLine();
                        Console.Write("Введите ('из', 'куда') для удаления ребра: ");
                        strArr = Console.ReadLine().Split();
                        if (strArr.Length == 2)
                        {
                            if (graph.DeleteEdge(strArr[0], strArr[1]))
                            {
                                Console.WriteLine("Ребро удалено");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Ребро не удалено, проверьте данные.");
                        }
                        Console.WriteLine();
                        break;
                    case 5:
                        Console.WriteLine();
                        graph.ShowLstVertex();
                        Console.WriteLine();
                        break;
                    case 6:
                        Console.WriteLine();
                        Console.WriteLine("Введите ссылку на файл.");
                        str = Console.ReadLine();
                        graph.OutPutInFile(str);
                        Console.WriteLine();
                        break;
                    case 0:
                        Console.WriteLine();
                        Console.WriteLine("Выход из программы.");
                        Console.WriteLine();
                        break;
                    default:
                        Console.WriteLine();
                        Console.WriteLine("Вы ввели не то число.");
                        Console.WriteLine();
                        break;
                }
            }
        }
    }
}